function save_geometry2(Geometry,geometry_folder,header_filename,density_filename)
% saves the Geometry file without the beam data in its matlab format to 
% files that are readable by a C-version of the convolution code.  
% The results are all saved in binary files so that no truncation errors 
% occur in the numbers.

warning off MATLAB:MKDIR:DirectoryExists

% load GeometryCT.mat;  % load the Matlab kernels, which look like:
% Geometry = 
% 
%          start: [-24.0128 -24.0128 -1.5000]
%     voxel_size: [0.3752 0.3752 0.3000]
%           data: [128x128x10 float]
%           beam: [1x1 struct]  % the beam field is not used by this file
%

mkdir(geometry_folder);

% density grid dimensions
[Xcount,Ycount,Zcount] = size(Geometry.data);

% create the geometry header file
fid = fopen([geometry_folder '/' header_filename],'w');
fprintf(fid,'Xcount Ycount Zcount\n');
fprintf(fid,'%g %g %g\n',Xcount,Ycount,Zcount);
fprintf(fid,'Xstart Ystart Zstart\n');
fprintf(fid,'%4.20E %4.20E %4.20E\n',double(Geometry.start(1)),double(Geometry.start(2)),double(Geometry.start(3)));
fprintf(fid,'dx dy dz\n');
fprintf(fid,'%4.20E %4.20E %4.20E\n',double(Geometry.voxel_size(1)),double(Geometry.voxel_size(2)),double(Geometry.voxel_size(3)));
fclose(fid);

% save the density data to a binary file
fid = fopen([geometry_folder '/' density_filename],'wb');
fwrite(fid,Geometry.rhomw,'float');
fclose(fid);