function save_kernels(Kernels,kernel_folder)
% saves the Kernels in their matlab format to files that are readable by a
% C-version of the convolution code.  The results are all saved in binary
% files so for easy readin.  Since there are so many files that will be
% created the option of changing the filenames from outside the function
% was not included.

warning off MATLAB:MKDIR:DirectoryExists

% The kernels have the following structure:
% Kernels = 
% 
%                radii: [1x24 float]
%               angles: [1x48 float]
%             energies: [1x14 float]
%              primary: [24x48x14 float]
%        first_scatter: [24x48x14 float]
%       second_scatter: [24x48x14 float]
%     multiple_scatter: [24x48x14 float]
%           brem_annih: [24x48x14 float]
%                total: [24x48x14 float]
%           mean_radii: [24x48x14 float]
%          mean_angles: [24x48x14 float]
%            helpfield: [21x72 char]            % not saved
%              fluence: [1x14 float]
%                   mu: [1x14 float]
%                mu_en: [1x14 float]

mkdir(kernel_folder);

% kernel filenames:

kernel_header = 'kernel_header.txt';  % header file for the kernels
kernel_radii = 'radii.bin';
kernel_angles = 'angles.bin';
kernel_energies = 'energies.bin';
kernel_primary = 'primary.bin';
kernel_first_scatter = 'first_scatter.bin';
kernel_second_scatter = 'second_scatter.bin';
kernel_multiple_scatter = 'multiple_scatter.bin';
kernel_brem_annih = 'brem_annih.bin';
kernel_total = 'total.bin';
kernel_fluence = 'fluence.bin';
kernel_mu = 'mu.bin';
kernel_mu_en = 'mu_en.bin';

[Nradii,Nangles,Nenergies] = size(Kernels.total);

% create the header file
fid = fopen([kernel_folder '/' kernel_header],'w');
fprintf(fid,'Nradii Nangles Nenergies\n');
fprintf(fid,'%g %g %g\n',Nradii,Nangles,Nenergies);
fclose(fid);

% start saving the rest of the data
fid = fopen([kernel_folder '/' kernel_radii],'wb');
fwrite(fid,Kernels.radii,'float');
fclose(fid);

fid = fopen([kernel_folder '/' kernel_angles],'wb');
fwrite(fid,Kernels.angles,'float');
fclose(fid);

fid = fopen([kernel_folder '/' kernel_energies],'wb');
fwrite(fid,Kernels.energies,'float');
fclose(fid);

fid = fopen([kernel_folder '/' kernel_primary],'wb');
fwrite(fid,Kernels.primary,'float');
fclose(fid);

fid = fopen([kernel_folder '/' kernel_first_scatter],'wb');
fwrite(fid,Kernels.first_scatter,'float');
fclose(fid);

fid = fopen([kernel_folder '/' kernel_second_scatter],'wb');
fwrite(fid,Kernels.second_scatter,'float');
fclose(fid);

fid = fopen([kernel_folder '/' kernel_multiple_scatter],'wb');
fwrite(fid,Kernels.multiple_scatter,'float');
fclose(fid);

fid = fopen([kernel_folder '/' kernel_brem_annih],'wb');
fwrite(fid,Kernels.brem_annih,'float');
fclose(fid);

fid = fopen([kernel_folder '/' kernel_total],'wb');
fwrite(fid,Kernels.total,'float');
fclose(fid);

fid = fopen([kernel_folder '/' kernel_fluence],'wb');
fwrite(fid,Kernels.fluence,'float');
fclose(fid);

fid = fopen([kernel_folder '/' kernel_mu],'wb');
fwrite(fid,Kernels.mu,'float');
fclose(fid);

fid = fopen([kernel_folder '/' kernel_mu_en],'wb');
fwrite(fid,Kernels.mu_en,'float');
fclose(fid);
