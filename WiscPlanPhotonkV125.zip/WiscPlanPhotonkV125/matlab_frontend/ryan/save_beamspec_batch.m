function save_beamspec_batch(batch,batch_folder,batch_file_name)
% Saves a beamspec batch to batch_folder/batch_filename. The batch is a
% cell array of beam structures.
%
% Each beam structure has the following fields:
% beam = 
% 
%        num: 1
%      y_vec: [86.6025 50.0000 0]
%        SAD: 100
%         ip: [0.5000 -0.8660 0]
%         jp: [0 0 1]
%         kp: [-0.8660 -0.5000 0]
%         xp: 0.5000
%         yp: 0
%     del_yp: 1
%     del_xp: 2

warning off MATLAB:MKDIR:DirectoryExists

mkdir(batch_folder);

N = prod(size(batch));  % number of beamspecs in the batch

fid = fopen([batch_folder '/' batch_file_name],'w');

fprintf(fid,'beamnum:\n %g\n\n',N);  % write the total number of beams that are in this batch

for k=1:N
    % save each beam structure
    beam = batch{k};        % current beam structure
    fprintf(fid,'num\n');
    fprintf(fid,'%g\n',double(beam.num));
    fprintf(fid,'SAD xp yp del_xp del_yp\n');
    fprintf(fid,'%4.20E %4.20E %4.20E %4.20E %4.20E\n',double(beam.SAD),double(beam.xp),double(beam.yp),double(beam.del_xp),double(beam.del_yp));
    fprintf(fid,'y_vec\n');
    fprintf(fid,'%4.20E %4.20E %4.20E\n',double(beam.y_vec(1)),double(beam.y_vec(2)),double(beam.y_vec(3)));
    fprintf(fid,'ip\n');
    fprintf(fid,'%4.20E %4.20E %4.20E\n',double(beam.ip(1)),double(beam.ip(2)),double(beam.ip(3)));
    fprintf(fid,'jp\n');
    fprintf(fid,'%4.20E %4.20E %4.20E\n',double(beam.jp(1)),double(beam.jp(2)),double(beam.jp(3)));
    fprintf(fid,'kp\n');
    fprintf(fid,'%4.20E %4.20E %4.20E\n\n',double(beam.kp(1)),double(beam.kp(2)),double(beam.kp(3)));
end
fclose(fid);