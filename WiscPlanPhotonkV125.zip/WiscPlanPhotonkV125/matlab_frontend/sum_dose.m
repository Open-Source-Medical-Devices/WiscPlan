function D = sum_dose(B, w)
if nargin < 2
    w = ones(size(B));
end
D = zeros(B{1}.x_count, B{1}.y_count, B{1}.z_count);
for k = 1:numel(B)
    if ~isempty(B{k}.non_zero_indices)
        D(B{k}.non_zero_indices) = D(B{k}.non_zero_indices) + w(k) * B{k}.non_zero_values;
    end
end


% imagesc(squeeze(D(26,:,:)))
% drawnow;