function setPositionXY(h, x, y, padding, max_height, units)
% SETPOSITIONXY Set graphical object position by x, y extents
% Input:
%   h = graphical object handle
%   x, y = 1x2 or 2x1 float, outer extent of the widget
%   padding = 1x2 or 2x1 float, internal padding

if nargin < 4
    % TODO
    return;
end

left = min(x) + padding(1);
bottom = min(y) + padding(2);
width = abs(x(1) - x(2)) - padding(1)*2;
height = abs(y(1) - y(2)) - padding(2)*2;

set(h, 'Position', [left bottom width height]);

if nargin >= 6
    % save Units
    old_units = get(h, 'Units');
    % restrict height
    set(h, 'Units', units);
    old_position = get(h, 'Position');
    if old_position(4) > max_height
        new_y = old_position(2) + (old_position(4) - max_height)/2;
        set(h, 'Position', [old_position(1) new_y old_position(3) max_height]);
    end
    % restore Units
    set(h, 'Units', old_units);
end
