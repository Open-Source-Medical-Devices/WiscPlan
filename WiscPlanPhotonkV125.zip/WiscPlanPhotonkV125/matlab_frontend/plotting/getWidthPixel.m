function width = getWidthPixel(h)
%GETWIDTHPIXEL Get the width of a graphical object in pixel
% Input:
%   h = graphical object handle

savedUnit = get(h, 'Unit');

set(h, 'Unit', 'pixels');
p = get(h, 'Position');
set(h, 'Unit', savedUnit);

width = p(3);

