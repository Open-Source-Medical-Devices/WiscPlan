%%
clf
% z = peaks;

CT = Geometry.rhomw(:,:,40);
z = optResults.dose{end}(:,:,40);

image(imagescX(CT, gray(256)));

% imagesc(z);
hold on
axis image
axis off

%%
[c, h] = contourf(z, 30:10:100, 'LineColor', 'auto');
% Find all the child objects that have the FaceAlpha property
alphable = findobj(h, 'Type', 'patch', '-property', 'FaceAlpha');
set(alphable, 'FaceAlpha', 0.1);
for i = 1:numel(alphable)
%     set(alphable(i), 'FaceVertexAlphaData', get(alphable(i), 'FaceVertexCData'));
    patch_value = get(alphable(i), 'CData');
    patch_value = patch_value(1);
    if patch_value <= 30
%         set(alphable(i), 'FaceAlpha', 0);
    end
end

%%
p = peaks(100);
subplot(1,2,1);
h = imagesc(p); colorbar;


levels = [-6 -2 1 8];
cmap = [0 0 1;
    0 1 0;
    1 0 0];
pimg = p;
for i = 1:numel(level)-1
    pimg(p>=level(i) & p<level(i+1)) = i;
end

subplot(1,2,2);
imagesc(pimg, 'CData', pimg, 'CDataMapping', 'direct');
colorbar;
% caxis([level(1) level(end)]);
colormap(cmap);

% colormap(jet(8));
% set(h, 'CDataMapping', 'direct');


%% caxis
index = fix((C-cmin)/(cmax-cmin)*m)+1;
%Clamp values outside the range [1 m]
index(index<1) = 1;
index(index>m) = m;
