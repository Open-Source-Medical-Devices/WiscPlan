function [Geometry patient_dir] = RDXTPS_geometry_setup_wizard()
%RDXTPS_geometry_setup_wizard Wizard to guide through plan geometry creation.
% Usage:
%   [ Geometry ] = dicomrt2geometry ( [input_dir] )
% Input:
%   input_dir = directory contains DicomRT data
%   [] = prompt to select input_dir
% Output:
%   Geometry = Ryan's Geometry struct used with RDX TPS
%
% This function imports DicomRT data set and create RDX TPS compatible Geometry
% struct.
%
% TODO change the description heading of this file.
% TODO allow multiple choices in target selections
%
% See also readPinnGeometry.m
%
% Author: Xiaohu Mo

total_num_steps = 4;
hWaitbar = waitbar(0);
set(hWaitbar, 'Unit', 'normalized');
op = get(hWaitbar, 'OuterPosition');
set(hWaitbar, 'OuterPosition', op + [0 0.2 0 0]);

%% -----===== DicomRT Import =====-----
waitbar(0/total_num_steps, hWaitbar, 'Step 1: Import DicomRT');
try
    Geometry = dicomrt2geometry();
catch EXCEPTION_DICOMRT2GEOMETRY
    msgbox('Failed to import DicomRT');
    delete(hWaitbar);
    rethrow(EXCEPTION_DICOMRT2GEOMETRY);
end

if isempty(Geometry)
    msgbox('Failed to import DicomRT');
    delete(hWaitbar);
    return;
end


%% -----===== BTV expansion =====-----
waitbar(1/total_num_steps, hWaitbar, 'Step 2: Assign target and BTV margin');
ROI_names = cellfun(@(c)c.name, Geometry.ROIS, 'UniformOutput', false);

[target_idx okay] = listdlg('ListString', ROI_names, ...
    'SelectionMode', 'single', 'Name', 'Target Selection', ...
    'PromptString', 'Please select the target ROI. ');
if okay ~= 1
    msgbox('Plan creation aborted');
    delete(hWaitbar);
    return;
end

[BTV_margin_answer] = inputdlg({sprintf('Please enter the BTV margin (cm):\n(default 0.6 cm or 1 sigma, enter 0 to skip)')}, ...
    'BTV margin specification', 1, {'0.6'});
if isempty(BTV_margin_answer)
    BTV_margin = 0.6;
else
    BTV_margin = str2double(BTV_margin_answer{1});
end

% target_idx and BTV_margin are set. Expand PTV to BTV
if BTV_margin > 0
    Geometry.BTV = false(size(Geometry.rhomw));
    % for target_idx = target_indices
        Geometry.BTV(Geometry.ROIS{target_idx}.ind) = 1;
    % end
    if exist('BTV_margin', 'var') && BTV_margin >= min(Geometry.voxel_size)
        bwD = bwdistsc(Geometry.BTV, Geometry.voxel_size);
        Geometry.BTV = bwD <= BTV_margin;
    end
end

%% -----===== Save geometry files =====-----
waitbar(2/total_num_steps, hWaitbar, 'Step 3: Save geometry files');

patient_dir = uifile('getdir', 'Save the patient data to directory');

% make directories
mkdir(patient_dir);
mkdir(fullfile(patient_dir, 'beamlet_batch_files'));
mkdir(fullfile(patient_dir, 'geometry_files'));
mkdir(fullfile(patient_dir, 'matlab_files'));
mkdir(fullfile(patient_dir, 'opt_input'));
mkdir(fullfile(patient_dir, 'opt_output'));

waitbar(2.33/total_num_steps, hWaitbar, 'Step 3: Save matlab geometry files');
% Save matlab geometry file
save(fullfile(patient_dir, 'matlab_files', 'Geometry.mat'), 'Geometry');

waitbar(2.66/total_num_steps, hWaitbar, 'Step 3: Save raw geometry files');
% Write binary geometry files
fid = fopen(fullfile(patient_dir, 'geometry_files', 'rhomw.bin'), 'w');
fwrite(fid, Geometry.rhomw, 'single');
fclose(fid);

fid = fopen(fullfile(patient_dir, 'geometry_files', 'Smw.bin'), 'w');
fwrite(fid, Geometry.Smw, 'single');
fclose(fid);

fid = fopen(fullfile(patient_dir, 'geometry_files', 'Fmw2.bin'), 'w');
fwrite(fid, Geometry.Fmw2, 'single');
fclose(fid);

fid = fopen(fullfile(patient_dir, 'geometry_files', 'target_mask.bin'), 'w');
fwrite(fid, Geometry.BTV, 'single');
fclose(fid);

% hWaitbar = waitbar(1/total_num_steps, 'Step 4, Create optimization geometry');

delete(hWaitbar);
msgbox(['Plan geometry created successfully in ' '"' patient_dir '"']);
