classdef SliceViewerPanelSource < handle
%SliceViewerPanelSource Root object of SliceViewerPanels
%
% SliceViewerPanelSource is used to store properties shared between a group of 
% SliceViewerPanel objects.
%
% See also XTPS, SliceViewerPanel
%
% Copyright Xiaohu Mo

    %%
    properties (SetObservable, AbortSet)
        POI = [1 1 1]           % point of intersection
        Geometry                % struct of various geometry data and settings
        % .ROIS                 % N x 1 cell array of ROI data
        %   .name               % char array, ROI name
        %   .visible            bool
        %   .color              N x 3 float between [0 1], RGB color
        optResults
        dosedisp                % struct of dose display settings
                                % .mode: consistant with DoseMode dropdown box
                                % .color: N x 3, float between [0 1]
                                % .level: N x 1, dose level in Gy
                                % .alpha: N x 1
        ctWindow                % struct of window width/window level
                                % .ww: scalar
                                % .wl: scalar
        hXTPS
        TCSVisible              % true/false toggle
    end
    
    properties (Dependent)
        ctClim                  % calculated based on windowlevel
    end
    
    properties (SetAccess = private)
        prev_POI = [1 1 1]      % used to avoid unnecessary redraws by comparing with new POI
    end

%===============================================================================
    methods
%-------------------------------------------------------------------------------
        function obj = SliceViewerPanelSource() % Constructor returns object
            num_dose_lvs = 10;
            obj.dosedisp = struct('mode', 'None', ...
                'color', rand(num_dose_lvs,3), ...
                'level', zeros(num_dose_lvs,1), ...
                'alpha', ones(num_dose_lvs,1));
            obj.ctWindow = struct('ww', 600, 'wl', 1000);
        end
%-------------------------------------------------------------------------------
        function set.POI(obj, value)
            obj.prev_POI = obj.POI;
            obj.POI = value;
        end
%-------------------------------------------------------------------------------
        function clim = get.ctClim(obj)
            clim = [obj.ctWindow.wl-obj.ctWindow.ww/2 obj.ctWindow.wl+obj.ctWindow.ww/2];
        end
    end
%===============================================================================
end
