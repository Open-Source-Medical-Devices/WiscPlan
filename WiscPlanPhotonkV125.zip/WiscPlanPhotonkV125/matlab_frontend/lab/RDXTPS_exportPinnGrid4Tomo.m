function RDXTPS_exportPinnGrid4Tomo (Geometry, optResults)
%RDXTPS_EXPORTPINNGRID4TOMO Export CT or dose grid to Pinnacle format for Tomo import
%   RDXTPS_exportPinnGrid4Tomo write the *.header and *.img pair in Pinnacle
%   format which can be imported into research version of Tomo TPS.
%
%   Example:
%       RDXTPS_exportPinnGrid4Tomo(Geometry, optResults)
%
%   See also N/A
%
%   Copyright Nobody

[filename, pathname] = uifile('put', '*', 'Save the export CT image as (without extension)');
ct_filebase = fullfile(pathname, filename);

% Write CT grid
fid = fopen([ct_filebase '.img'], 'w');
fwrite(fid, apply_transformation(Geometry.data), 'short');
fclose(fid);

% Write CT header
fid = fopen([ct_filebase '.header'], 'w');
fprintf(fid, 'read_conversion : \n');
fprintf(fid, 'write_conversion : \n');
fprintf(fid, 'data_type : short\n');
fprintf(fid, 'byte_order = 0\n');
fprintf(fid, 'bytes_pix = 2\n');
fprintf(fid, 'vol_min = \n');
fprintf(fid, 'vol_max = \n');
fprintf(fid, 'x_dim = %d\n', size(Geometry.rhomw, 1));
fprintf(fid, 'y_dim = %d\n', size(Geometry.rhomw, 2));
fprintf(fid, 'z_dim = %d\n', size(Geometry.rhomw, 3));
fprintf(fid, 'dim_units : \n');
fprintf(fid, 'x_pixdim = %f\n', Geometry.voxel_size(1));
fprintf(fid, 'y_pixdim = %f\n', Geometry.voxel_size(2));
fprintf(fid, 'z_pixdim = %f\n', Geometry.voxel_size(3));
fprintf(fid, 'x_start = %f\n', Geometry.start(1));
fprintf(fid, 'y_start = %f\n', Geometry.start(2));
fprintf(fid, 'z_start = %f\n', Geometry.start(3));
fprintf(fid, 'date : \n');
fprintf(fid, 'db_name : \n');
fclose(fid);


% Repeat for dose
[filename, pathname] = uifile('put', '*', 'Save the export dose image as (without extension)');
dose_filebase = fullfile(pathname, filename);

% Write dose grid
fid = fopen([dose_filebase '.img'], 'w');
fwrite(fid, apply_transformation(optResults.dose{end}), 'single');
fclose(fid);

% Write dose header
fid = fopen([dose_filebase '.header'], 'w');
fprintf(fid, 'read_conversion : \n');
fprintf(fid, 'write_conversion : \n');
fprintf(fid, 'data_type : float\n');
fprintf(fid, 'byte_order = 0\n');
fprintf(fid, 'bytes_pix = 4\n');
fprintf(fid, 'vol_min = \n');
fprintf(fid, 'vol_max = \n');
fprintf(fid, 'x_dim = %d\n', size(Geometry.rhomw, 1));
fprintf(fid, 'y_dim = %d\n', size(Geometry.rhomw, 2));
fprintf(fid, 'z_dim = %d\n', size(Geometry.rhomw, 3));
fprintf(fid, 'dim_units : \n');
fprintf(fid, 'x_pixdim = %f\n', Geometry.voxel_size(1));
fprintf(fid, 'y_pixdim = %f\n', Geometry.voxel_size(2));
fprintf(fid, 'z_pixdim = %f\n', Geometry.voxel_size(3));
fprintf(fid, 'x_start = %f\n', Geometry.start(1));
fprintf(fid, 'y_start = %f\n', Geometry.start(2));
fprintf(fid, 'z_start = %f\n', Geometry.start(3));
fprintf(fid, 'date : \n');
fprintf(fid, 'db_name : \n');
fclose(fid);

    % Apply appropriate transformation to fit Pinnacle format to input matrix M
    function M = apply_transformation(M)
        for i = 1:size(M, 3)
            M(:,:,i) = rot90(M(:,:,i), 1);
        end
        M = flipdim(M, 3);
    end

end