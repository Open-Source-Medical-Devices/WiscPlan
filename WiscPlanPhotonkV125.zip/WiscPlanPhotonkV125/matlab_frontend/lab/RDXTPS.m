function RDXTPS()
%RDXTPS calls XTPS constructor and provide an entrance point for deploytool

XTPS();
