function [ lsoutp ] = lsl ( directory )
%LS Substitute 'ls' function to return compatible output on Win and Unix
%   The default 'ls' function behave differently on Windows and Unix platforms.
%   This function returns a char matrix contains 'ls' results including ., ..,
%   files, and folders). Spaces are appended to each string as necessary to form
%   a valid matrix.

if nargin < 1
    directory = '.';
end

if ispc
    lsoutp = ls ( directory );
elseif isunix || ismac
    dirtmp = dir ( directory );
    lsoutp = strvcat ( {dirtmp.name} );
else
    error ( 'unknow platform' );
end
