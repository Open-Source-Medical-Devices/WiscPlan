function dens = CT2dens(CTimage,imgtype)
% converts the CT image to physical density based on one of the IVDT tables
% listed below.

GE_LS_PD_hu = [-1024 -689 -518 -92 -50 0 73 214 225 450 812 1201]; 
GE_LS_PD_dens = [0.0 0.29 0.46 0.947 0.976 1 1.094 1.144 1.153 1.335 1.561 1.824];

% MVCT_hu = [-1024 -682 -494 -54 44 103 118 132 296 463 717 2584];
% MVCT_dens = [0.0 0.3 0.41 0.92 1 1.11 1.14 1.16 1.39 1.56 1.82 4.59];

MVCT_hu = [-1024 -662 -490 -33 2 33 93 107 144 148 314 722 2588];
MVCT_dens = [0 0.29 0.46 0.947 0.976 1 1.051 1.094 1.144 1.153 1.335 1.824 4.59];

if strcmp(imgtype,'pinn') || strcmp(imgtype,'tomo')
    GE_hu = GE_LS_PD_hu + 1024;
    dens = interp1(GE_hu,GE_LS_PD_dens,double(CTimage),'linear','extrap');
elseif strcmp(imgtype,'mvct') || strcmp(imgtype,'reg')
    mvct_hu = MVCT_hu + 1024;
    dens = interp1(mvct_hu,MVCT_dens,double(CTimage),'linear','extrap');
else
    fprintf('Error: Could not determine density values from CT image.\n');
end
