function flg = checkDictUse
% Since MATLAB 7.3(2006A) and 7.4(2006B) doesnot support dicom dictionary
% this function checks the matlab version and returns the flag to allow the
% use of dictionary.
%
% DK 

% copyright (c) 2001-2007, Washington University in St. Louis.
% Permission is granted to use or modify only for non-commercial, 
% non-treatment-decision applications, and further only if this header is 
% not removed from any file. No warranty is expressed or implied for any 
% use whatever: use at your own risk.  Users can request use of CERR for 
% institutional review board-approved protocols.  Commercial users can 
% request a license.  Contact Joe Deasy for more information 
% (radonc.wustl.edu@jdeasy, reversed).

% set flag to 1 so as to always use Dictionary
flg = 1;

mathVer = version;

% XMO: Old bug code. Does not work for version 7.10
% if str2num(mathVer(1:3)) > 7.3
v = sscanf(mathVer, '%d.%d.%s');
if v(1) + v(2)/10 > 7.3
    flg = 0;   
end

return