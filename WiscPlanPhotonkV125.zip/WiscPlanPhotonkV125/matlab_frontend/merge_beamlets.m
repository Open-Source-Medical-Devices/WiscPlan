function B = merge_beamlets(num_batches)

num_batches = 2;


B = [];
for k = 1:num_batches
    batch_doses = read_ryan_beamlets(['C:\WiscPlanPhotonkV\PatientData\batch_dose' num2str(k-1) '.bin']);
    B = [B batch_doses];
end

for k = 1:numel(B)
    B{k}.num = k-1;
end
write_ryan_beamlets('C:\WiscPlanPhotonkV\PatientData\batch_dose.bin',B);
