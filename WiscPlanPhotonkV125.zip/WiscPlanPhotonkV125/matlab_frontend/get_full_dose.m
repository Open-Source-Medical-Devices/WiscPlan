function get_full_dose()

optResultsFile = 'C:\WiscPhotonkV\work\Patients\TomoPhant1\matlab_files\optResults.mat';


load(optResultsFile);
D = read_ryan_beamlets('C:\WiscPhotonkV\work\Patients\TomoPhant1\beamlet_batch_files\beamletbatch0.bin','ryan sum', optResults.weights{end});
optResults.batchNames{end+1} = optResults.batchNames{end};
optResults.dose{end+1} = D;
optResults.weights{end+1} = optResults.weights{end};
save(optResultsFile, 'optResults', 'optSettings');
