function [str] = rgb2str(c)
% RGB2STR Utility function converts uisetcolor's RGB color to string
% Usage:
%   str = rgb2str(c)
% Input:
%   c = 1x3 float of RGB values between [0 1]
% Output:
%   str = html color code format, e.g. color(23, 47, 83)
%
% Xiaohu Mo

if isvector(c) && numel(c) == 3
    c = round(c * 255);
    str = sprintf('rgb(%d, %d, %d)', c(1), c(2), c(3));
end
