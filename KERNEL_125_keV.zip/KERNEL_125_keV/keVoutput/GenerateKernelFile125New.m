% Surendra Prajapati 2014
% This code  creates kernel provided the EGS output file --> "... .KeV" 
% and provided text files that provides fluence(spectrum of source), mu/rho and mu-en/rho


close all;
clear all;

cd('E:\UW MADISON\Wisc Fall 2014\Kernels for 125keV and 250 keV\KERNEL_125_keV\keVoutput')

rad= [0.01,0.03,0.05,0.08,0.11,0.15,0.2,0.3,0.4,0.6,0.8,1.1,1.5,2.0,3.0,4.0,6.0,8.0,10.0,15.0,20.0,30.0,45.0,60.0];
ang = [3.75:3.75:180];
energyarr = [5:5:125];
Kernels.radii = rad;
Kernels.angles = ang;
Kernels.energies = energyarr/1000;

for count = 1:length(energyarr)
    str = strcat(num2str(energyarr(count)),'keV_XCOM_HighRes.keV');
    %C(count) = texscan(str,'%f %f');
    [val stdev] = textread(str, '%f %f');
    Data(:,:,:,count) = reshape(val,5,24,48);
end

for count = 1:5
    k = Data(count,:,:,:);
    temp(:,:,:,count) = reshape(k,24,48,length(energyarr));
end

Kernels.primary = temp(:,:,:,1);
Kernels.first_scatter = temp(:,:,:,2);
Kernels.second_scatter = temp(:,:,:,3);
Kernels.multiple_scatter = temp(:,:,:,4);
Kernels.brem_annih = temp(:,:,:,5);
Kernels.total = Kernels.primary + Kernels.first_scatter + Kernels.second_scatter + Kernels.multiple_scatter + Kernels.brem_annih;


A = textread('125keVfluence.txt');
B = textread('125keVmu_mu-en.txt');

Kernels.fluence = A(:,2)';
Kernels.mu = B(:,2)';
Kernels.mu_en = B(:,3)';

save Kernels.mat

% for count = 1:5
%     k = test_data(count,:,:,:);
%     temp(:,:,:,count) = reshape(k,24,48,length(energyarr));
% end

